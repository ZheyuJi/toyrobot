/**
 * 
 * Global configuration
 * @author zheyuji
 *
 */
public class Global {
	public static final int MAX_X = 4;
	public static final int MIN_X = 0;
	public static final int MAX_Y = 4;
	public static final int MIN_Y = 0;
	public static final int STEP = 1;
	public static final int PLACE_CMD_LEN = 2;
	public static final int PLACE_CMD_DATA_LEN = 3;
}
